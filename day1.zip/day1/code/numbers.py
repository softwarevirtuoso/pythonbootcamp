x = 10  # int
y = 7.5 # float
z = 2j  # complex

 # Decimal literals
x = 400
z = 2652565188198713537826762234234234 # very long numbers are integers
k = -30 # negative numbers

# Binary literals
bin1 = 0b1101   # starts with 0b (zero b)

# Octal literals
oct1 = 0o234    # starts with 0o (zero and "o" )

#   Hexadecimal literals
hex1 = 0x14b     # starts with 0x (zero and ex )

#   Floats
float_literal1 = 34.12
float_literal_neg = -46.09
#   Float can also be scientific numbers with an "e" to indicate the power of 10.
float_literal2 = 65e3
float_literal3 = 23E4

#   Complex Number
c = 5.23j

print(x, type(x))
print(bin1, type(bin1))
print(oct1, type(oct1))
print(hex1, type(hex1))
print(float_literal1, type(float_literal1))
print(c, type(c))

##Numeric Operations

>>> 3 + 3
6
>>> 60 - 5*6
30
>>> (60 - 5*6) / 4
7.5
>>> 18 / 5  # division always returns a floating point number
3.6

>>> 17 / 3  # classic division returns a float
5.666666666666667
>>>
>>> 17 // 3  # floor division discards the fractional part
5
>>> 17 % 3  # the % operator returns the remainder of the division
2
>>> 5 * 3 + 2  # result * divisor + remainder
17

>>> 5 ** 2  # 5 squared
25
>>> 2 ** 7  # 2 to the power of 7
128