#https://www.youtube.com/watch?v=Lp9Ftuq2sVI
#https://www.youtube.com/watch?v=EztlAyuOg6o
#https://www.codewithharry.com/videos/python-tutorials-for-absolute-beginners-120
import pyttsx3
engine=pyttsx3.init('sapi5')
voices=engine.getproperty('voices')
#print(voices[0].id)
engine.setProperty('voices',voices[0].id)
def speak(audio):
	engine.say(audio)
                    engine.runAndWait()
	