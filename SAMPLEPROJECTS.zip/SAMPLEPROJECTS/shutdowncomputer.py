import os
def shutdown_PC():
    os.system("shutdown /s /t 1")
shutdown_PC()