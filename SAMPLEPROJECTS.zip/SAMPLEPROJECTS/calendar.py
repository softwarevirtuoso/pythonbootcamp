import calendar
print(calendar.month(2021, 9))